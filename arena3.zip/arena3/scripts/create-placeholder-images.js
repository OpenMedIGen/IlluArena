const fs = require('fs');
const path = require('path');
const { createCanvas } = require('canvas');

// 创建占位图片的函数
function createPlaceholderImage(width, height, text, color) {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // 填充背景色
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, width, height);
  
  // 添加文字
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, width / 2, height / 2);
  
  return canvas.toBuffer('image/jpeg');
}

// 图片配置
const images = [
  { path: 'public/images/dalle3/dragon_sunset.jpg', text: 'DALLE-3\nDragon', color: '#FF6B6B' },
  { path: 'public/images/dalle3/future_city.jpg', text: 'DALLE-3\nCity', color: '#4ECDC4' },
  { path: 'public/images/dalle3/japanese_garden.jpg', text: 'DALLE-3\nGarden', color: '#45B7D1' },
  { path: 'public/images/dalle3/astronaut_space.jpg', text: 'DALLE-3\nSpace', color: '#96CEB4' },
  { path: 'public/images/dalle3/magical_forest.jpg', text: 'DALLE-3\nForest', color: '#FFEAA7' },
  { path: 'public/images/midjourney/dragon_sunset.jpg', text: 'MJ\nDragon', color: '#DDA0DD' },
  { path: 'public/images/midjourney/future_city.jpg', text: 'MJ\nCity', color: '#98D8C8' },
  { path: 'public/images/midjourney/japanese_garden.jpg', text: 'MJ\nGarden', color: '#F7DC6F' },
  { path: 'public/images/midjourney/astronaut_space.jpg', text: 'MJ\nSpace', color: '#85C1E2' },
  { path: 'public/images/midjourney/magical_forest.jpg', text: 'MJ\nForest', color: '#F8B739' },
];

// 创建所有图片
images.forEach(img => {
  const dir = path.dirname(img.path);
  
  // 确保目录存在
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  // 创建图片
  const buffer = createPlaceholderImage(512, 512, img.text, img.color);
  fs.writeFileSync(img.path, buffer);
  console.log(`Created: ${img.path}`);
});

console.log('All placeholder images created successfully!');