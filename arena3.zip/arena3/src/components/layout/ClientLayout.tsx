'use client'

import { useState } from "react";
import { SessionProvider as NextAuthSessionProvider } from "next-auth/react";
import { Sidebar } from "@/components/layout/Sidebar";

export function ClientLayout({ children }: { children: React.ReactNode }) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <NextAuthSessionProvider>
      <div className="flex h-screen">
        <Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
        <main className={`flex-1 flex flex-col transition-all duration-300 ${isCollapsed ? 'ml-20' : 'ml-64'}`}>
          <div className="p-4 md:p-6 lg:p-8 flex-grow">
            {children}
          </div>
        </main>
      </div>
    </NextAuthSessionProvider>
  );
}