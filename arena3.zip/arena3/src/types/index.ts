export interface BattleData {
  id: string;
  modelA: {
    id: string;
    name: string;
    displayName: string;
    image: string;
    prompt: string;
    promptZh?: string;
  };
  modelB: {
    id: string;
    name: string;
    displayName: string;
    image: string;
    prompt: string;
    promptZh?: string;
  };
  mode: 'anonymous' | 'public';
}

export interface VoteResult {
  winner: 'A' | 'B' | 'both_good' | 'both_bad' | 'skip';
  modelA: {
    id: string;
    name: string;
    displayName: string;
    oldRating: number;
    newRating: number;
  };
  modelB: {
    id: string;
    name: string;
    displayName: string;
    oldRating: number;
    newRating: number;
  };
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  displayName: string;
  rating: number;
  votes: number;
  rank: number;
  gamesPlayed: number;
  confidenceInterval: [number, number];
  winRate: number;
}

export interface User {
  id: string;
  username: string;
  email: string;
}

export interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

export type BattleMode = 'anonymous' | 'public';
export type VoteOption = 'A' | 'B' | 'both_good' | 'both_bad' | 'skip';
export type LeaderboardType = 'overall' | 'anonymous' | 'public';