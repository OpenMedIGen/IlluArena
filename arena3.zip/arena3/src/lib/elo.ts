export interface ELOResult {
  newRatingA: number;
  newRatingB: number;
}

/**
 * 计算ELO评分
 * @param ratingA 模型A的当前评分
 * @param ratingB 模型B的当前评分
 * @param result 比赛结果 ('A' | 'B' | 'tie')
 * @param k K因子，默认为4
 * @returns 新的评分
 */
export function calculateELO(
  ratingA: number,
  ratingB: number,
  result: 'A' | 'B' | 'tie' | 'both_good' | 'both_bad' | 'skip',
  k: number = 4
): ELOResult {
  // 跳过时不改变评分
  if (result === 'skip') {
    return {
      newRatingA: ratingA,
      newRatingB: ratingB
    };
  }
  
  // 计算期望得分
  const expectedA = 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
  const expectedB = 1 - expectedA;
  
  // 实际得分
  let scoreA: number, scoreB: number;
  let weight: number;
  
  if (result === 'A') {
    scoreA = 1;
    scoreB = 0;
    weight = 1.0; // 明确选择，权重最大
  } else if (result === 'B') {
    scoreA = 0;
    scoreB = 1;
    weight = 1.0; // 明确选择，权重最大
  } else if (result === 'tie' || result === 'both_good' || result === 'both_bad') {
    // 平局、两个都好、两个都差
    scoreA = 0.5;
    scoreB = 0.5;
    weight = 0.5; // 不明确的选择，权重降低
  } else {
    // 默认平局处理
    scoreA = 0.5;
    scoreB = 0.5;
    weight = 0.5;
  }
  
  // 计算新评分
  const newRatingA = ratingA + k * weight * (scoreA - expectedA);
  const newRatingB = ratingB + k * weight * (scoreB - expectedB);
  
  return {
    newRatingA: Math.round(newRatingA), // 四舍五入到整数
    newRatingB: Math.round(newRatingB)
  };
}

/**
 * 计算胜率
 * @param ratingA 模型A的评分
 * @param ratingB 模型B的评分
 * @returns 模型A对模型B的胜率
 */
export function calculateWinProbability(ratingA: number, ratingB: number): number {
  return 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
}