# AI Image Battle Ranking System

这是一个基于 Next.js、Prisma 和 NextAuth.js 构建的 AI 图像对战排名系统。用户可以对 AI 生成的图像进行投票，系统会根据投票结果更新图像的 Elo 排名。

## 目录

- [功能](#功能)
- [技术栈](#技术栈)
- [快速开始](#快速开始)
  - [先决条件](#先决条件)
  - [安装](#安装)
  - [运行开发服务器](#运行开发服务器)
- [添加新的模型生成图片和 JSON 信息](#添加新的模型生成图片和-json-信息)
  - [步骤 1: 准备图片文件](#步骤-1-准备图片文件)
  - [步骤 2: 更新 JSON 数据](#步骤-2-更新-json-数据)
  - [步骤 3: 验证更改](#步骤-3-验证更改)
- [数据库](#数据库)
  - [Prisma 迁移](#prisma-迁移)
  - [数据 seeding](#数据-seeding)
- [认证](#认证)
- [API 路由](#api-路由)
- [部署](#部署)

## 功能

- **图像对战**: 用户可以对两张 AI 生成的图像进行投票。
- **Elo 排名系统**: 根据投票结果实时更新图像的 Elo 排名。
- **排行榜**: 显示图像的实时排名。
- **用户认证**: 使用 NextAuth.js 进行用户注册和登录。
- **响应式设计**: 适用于不同设备。

## 技术栈

- **框架**: Next.js 14 (App Router)
- **数据库**: PostgreSQL (通过 Prisma ORM)
- **认证**: NextAuth.js
- **样式**: Tailwind CSS
- **类型检查**: TypeScript

## 快速开始

### 先决条件

在开始之前，请确保您的开发环境中安装了以下软件：

- Node.js (v18 或更高版本)
- npm 或 Yarn
- PostgreSQL 数据库

### 安装

1.  克隆仓库:
    ```bash
    git clone https://github.com/your-username/ai-image-battle.git
    cd ai-image-battle
    ```
2.  安装依赖:
    ```bash
    npm install
    # 或者
    yarn install
    ```
3.  创建 `.env` 文件:
    复制 `.env.example` 文件并将其重命名为 `.env`。然后更新其中的环境变量，特别是数据库连接字符串和 NextAuth.js 的相关配置。

    ```dotenv
    DATABASE_URL="postgresql://user:password@localhost:5432/ai_image_battle"
    NEXTAUTH_SECRET="your_nextauth_secret"
    NEXTAUTH_URL="http://localhost:3000"
    GOOGLE_CLIENT_ID="your_google_client_id"
    GOOGLE_CLIENT_SECRET="your_google_client_secret"
    ```

    - `DATABASE_URL`: 您的 PostgreSQL 数据库连接字符串。
    - `NEXTAUTH_SECRET`: 用于加密 NextAuth.js 会话的秘密字符串。可以使用 `openssl rand -base64 32` 生成。
    - `NEXTAUTH_URL`: 您的应用程序的 URL (开发环境通常是 `http://localhost:3000`)。
    - `GOOGLE_CLIENT_ID` 和 `GOOGLE_CLIENT_SECRET`: 如果您想启用 Google 登录，请在 Google Cloud Console 中创建 OAuth 凭据。

4.  运行 Prisma 迁移并生成客户端:
    ```bash
    npx prisma migrate dev --name init
    npx prisma generate
    ```
5.  填充初始数据 (可选):
    ```bash
    npm run seed
    ```

### 运行开发服务器

```bash
npm run dev
# 或者
yarn dev
```

在浏览器中打开 [http://localhost:3000](http://localhost:3000) 查看结果。

## 添加新的模型生成图片和 JSON 信息

如果您想增加新的模型生成的图片和对应的 JSON 信息，请按照以下步骤操作：

### 步骤 1: 准备图片文件

将新的图片文件放置在 `public/images/dalle3/` 或 `public/images/midjourney/` 目录下。确保图片文件名是唯一的且具有描述性。

例如，如果您要添加一张名为 `new_image.jpg` 的 DALL-E 3 图片，您应该将其放置在 `public/images/dalle3/new_image.jpg`。

### 步骤 2: 更新 JSON 数据

根据您添加的图片类型，编辑 `data/DALLE-3.json` 或 `data/MJ.json` 文件。

每个 JSON 文件都包含一个图像对象数组，每个对象应包含以下字段：

-   `id`: 唯一的字符串或数字 ID。请确保这个 ID 在文件中是唯一的。
-   `prompt`: 图片的英文描述。
-   `prompt_zh`: 图片的中文描述。
-   `image_path`: 图片在 `public` 目录下的相对路径。

**示例 (添加 DALL-E 3 图片):**

打开 `data/DALLE-3.json` 文件，并在数组末尾添加一个新的对象：

```json
[
  {
    "id": "1",
    "prompt": "A majestic dragon soaring through a sunset sky with golden clouds",
    "prompt_zh": "一条威严的龙在金色云彩的夕阳天空中翱翔",
    "image_path": "/images/dalle3/dragon_sunset.jpg"
  },
  // ... 其他图片
  {
    "id": "6",
    "prompt": "A futuristic cyberpunk city with neon signs and flying vehicles at night",
    "prompt_zh": "夜晚有霓虹灯和飞行器的未来赛博朋克城市",
    "image_path": "/images/dalle3/cyberpunk_city.jpg"
  }
]
```

请确保新的 `id` 是唯一的，并且 `image_path` 正确指向您在步骤 1 中放置的图片文件。

### 步骤 3: 验证更改

1.  保存您对 JSON 文件的更改。
2.  如果开发服务器正在运行，它应该会自动重新加载。如果没有，请重新启动开发服务器：
    ```bash
    npm run dev
    ```
3.  访问应用程序，检查新的图片是否出现在对战页面或排行榜中。

## 数据库

本项目使用 Prisma 作为 ORM 来管理 PostgreSQL 数据库。

### Prisma 迁移

当您更改 `prisma/schema.prisma` 文件时，需要创建并应用新的迁移：

```bash
npx prisma migrate dev --name your_migration_name
```

### 数据 seeding

`src/lib/seed.ts` 文件用于向数据库填充初始图像数据。在开发环境中，您可以使用以下命令运行 seed 脚本：

```bash
npm run seed
```

**注意**: 运行 `seed` 命令会删除并重新创建 `Image` 表中的所有数据。请谨慎使用。

## 认证

本项目使用 NextAuth.js 进行用户认证。目前支持通过 Google 进行 OAuth 登录，以及通过用户名/密码进行注册和登录。

-   **Google OAuth**: 在 `.env` 文件中配置 `GOOGLE_CLIENT_ID` 和 `GOOGLE_CLIENT_SECRET`。
-   **凭据提供者**: 用户可以通过 `/register` 页面注册，并通过 `/login` 页面登录。

## API 路由

-   `src/app/api/auth/[...nextauth]/route.ts`: NextAuth.js 的认证路由。
-   `src/app/api/auth/register/route.ts`: 用户注册 API。
-   `src/app/api/battle/route.ts`: 处理图像对战投票的 API。
-   `src/app/api/leaderboard/route.ts`: 获取排行榜数据的 API。

## 部署

在部署到生产环境之前，请确保您的 `.env` 文件中的环境变量已正确配置，特别是 `DATABASE_URL` 和 `NEXTAUTH_SECRET`。

构建生产版本：

```bash
npm run build
```

启动生产服务器：

```bash
npm start
