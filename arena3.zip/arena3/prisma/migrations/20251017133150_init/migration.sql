-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "username" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "models" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "displayName" TEXT NOT NULL,
    "description" TEXT,
    "eloOverall" REAL NOT NULL DEFAULT 1000.0,
    "eloAnonymous" REAL NOT NULL DEFAULT 1000.0,
    "eloPublic" REAL NOT NULL DEFAULT 1000.0,
    "totalVotes" INTEGER NOT NULL DEFAULT 0,
    "anonymousVotes" INTEGER NOT NULL DEFAULT 0,
    "publicVotes" INTEGER NOT NULL DEFAULT 0,
    "winsOverall" INTEGER NOT NULL DEFAULT 0,
    "winsAnonymous" INTEGER NOT NULL DEFAULT 0,
    "winsPublic" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "battles" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "modelAId" TEXT NOT NULL,
    "modelBId" TEXT NOT NULL,
    "promptId" TEXT NOT NULL,
    "mode" TEXT NOT NULL,
    "result" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "battles_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "battles_modelAId_fkey" FOREIGN KEY ("modelAId") REFERENCES "models" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "battles_modelBId_fkey" FOREIGN KEY ("modelBId") REFERENCES "models" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "image_data" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "promptId" TEXT NOT NULL,
    "modelId" TEXT NOT NULL,
    "prompt" TEXT NOT NULL,
    "promptZh" TEXT,
    "imagePath" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "image_data_modelId_fkey" FOREIGN KEY ("modelId") REFERENCES "models" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "models_name_key" ON "models"("name");

-- CreateIndex
CREATE UNIQUE INDEX "image_data_promptId_modelId_key" ON "image_data"("promptId", "modelId");
