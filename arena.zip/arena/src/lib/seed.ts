const { prisma } = require('./prisma')
const fs = require('fs')
const path = require('path')

interface ImageDataJson {
  id: string
  prompt: string
  prompt_zh?: string
  image_path: string
}

async function seedDatabase() {
  try {
    console.log('开始初始化数据库...')

    // 清理现有数据
    await prisma.battle.deleteMany()
    await prisma.imageData.deleteMany()
    await prisma.model.deleteMany()

    // 创建模型数据
    const models = [
      {
        name: 'DALLE-3',
        displayName: 'DALL-E 3',
        description: 'OpenAI的最新图像生成模型'
      },
      {
        name: 'MJ',
        displayName: 'Midjourney',
        description: 'Midjourney图像生成模型'
      }
    ]

    const createdModels = await Promise.all(
      models.map(model => 
        prisma.model.create({
          data: model
        })
      )
    )

    console.log('模型创建完成:', createdModels.map(m => m.displayName))

    // 读取并导入图片数据
    const dataDir = path.join(process.cwd(), 'data')
    
    for (const model of createdModels) {
      const jsonFile = path.join(dataDir, `${model.name}.json`)
      
      if (fs.existsSync(jsonFile)) {
        console.log(`正在导入 ${model.displayName} 的数据...`)
        
        const jsonData = JSON.parse(fs.readFileSync(jsonFile, 'utf-8')) as ImageDataJson[]
        
        const imageDataToCreate = jsonData.map(item => ({
          promptId: item.id,
          modelId: model.id,
          prompt: item.prompt,
          promptZh: item.prompt_zh || null,
          imagePath: item.image_path
        }))

        await prisma.imageData.createMany({
          data: imageDataToCreate
        })

        console.log(`${model.displayName} 数据导入完成: ${imageDataToCreate.length} 条记录`)
      } else {
        console.log(`警告: 找不到文件 ${jsonFile}`)
      }
    }

    console.log('数据库初始化完成!')
    
    // 显示统计信息
    const modelCount = await prisma.model.count()
    const imageCount = await prisma.imageData.count()
    
    console.log(`统计信息:`)
    console.log(`- 模型数量: ${modelCount}`)
    console.log(`- 图片数据: ${imageCount}`)

  } catch (error) {
    console.error('数据库初始化失败:', error)
    throw error
  }
}

async function checkUser(userId: string) {
  try {
    console.log(`正在查询用户 ID: ${userId}`);
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (user) {
      console.log('用户存在:', user);
    } else {
      console.log('用户不存在，ID:', userId);
    }
    return user;
  } catch (error) {
    console.error('查询用户失败:', error);
    return null;
  }
}

module.exports = { seedDatabase, checkUser }
 
// 如果直接运行此脚本
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log('数据初始化成功!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('数据初始化失败:', error)
      process.exit(1)
    })
}