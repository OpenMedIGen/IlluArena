'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { BattleData, VoteResult } from '@/types'
import {
  EyeIcon,
  EyeSlashIcon,
  ArrowPathIcon,
  HandThumbUpIcon,
  HandThumbDownIcon,
  MinusIcon,
  LanguageIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from '@heroicons/react/24/outline'

export default function BattlePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [battleData, setBattleData] = useState<BattleData | null>(null)
  const [mode, setMode] = useState<'anonymous' | 'public'>('anonymous')
  const [isLoading, setIsLoading] = useState(false)
  const [isVoting, setIsVoting] = useState(false)
  const [voteResult, setVoteResult] = useState<VoteResult | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [showEnglishPrompt, setShowEnglishPrompt] = useState(false)
  const [showModelNames, setShowModelNames] = useState(false)

  // 获取新的对战数据
  const fetchBattleData = async () => {
    setIsLoading(true)
    setVoteResult(null)
    setShowResult(false)
    // 根据模式设置showModelNames的初始状态
    if (mode === 'anonymous') {
      setShowModelNames(false)
    } else if (mode === 'public') {
      setShowModelNames(true)
    }
    
    try {
      const response = await fetch(`/api/battle?mode=${mode}`)
      if (response.ok) {
        const data = await response.json()
        setBattleData(data)
      } else {
        // 使用更安全的错误处理方式
        if (typeof window !== 'undefined') {
          console.log('Failed to fetch battle data')
        }
      }
    } catch (error) {
      // 使用更安全的错误处理方式
      if (typeof window !== 'undefined') {
        console.log('Error fetching battle data:', error)
      }
    } finally {
      setIsLoading(false)
    }
  }

  // 提交投票
  const handleVote = async (choice: 'A' | 'B' | 'both_good' | 'both_bad' | 'skip') => {
    // 跳过不需要登录
    if (choice === 'skip') {
      fetchBattleData()
      return
    }
    
    if (!session?.user || !battleData) {
      router.push('/login')
      return
    }

    setIsVoting(true)
    
    try {
      const response = await fetch('/api/battle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          modelAId: battleData.modelA.id,
          modelBId: battleData.modelB.id,
          result: choice,
          mode: battleData.mode,
          promptId: (battleData as any).promptId
        }),
      })

      if (response.ok) {
        // 模拟投票结果显示（实际应该从API返回）
        const mockResult: VoteResult = {
          winner: choice,
          modelA: {
            id: battleData.modelA.id,
            name: battleData.modelA.name,
            displayName: battleData.modelA.displayName,
            oldRating: 1000, // 这里应该从API获取
            newRating: choice === 'A' ? 1020 : (choice === 'both_good' || choice === 'both_bad') ? 1005 : 980
          },
          modelB: {
            id: battleData.modelB.id,
            name: battleData.modelB.name,
            displayName: battleData.modelB.displayName,
            oldRating: 1000,
            newRating: choice === 'B' ? 1020 : (choice === 'both_good' || choice === 'both_bad') ? 1005 : 980
          }
        }
        if (mode === 'anonymous') {
          setShowModelNames(true) // 匿名模式下投票后显示模型名称
          setTimeout(() => {
            setShowModelNames(false)
            fetchBattleData()
          }, 2000) // 2秒后自动换下一组对战
        } else if (mode === 'public') {
          // 公开模式下，模型名称始终显示，直接获取下一组对战数据
          fetchBattleData()
        } else {
          setVoteResult(mockResult)
          setShowResult(true)
        }
      }
      else {
        // 使用更安全的错误处理方式
        if (typeof window !== 'undefined') {
          console.log('Failed to submit vote')
        }
      }
    } catch (error) {
      // 使用更安全的错误处理方式
      if (typeof window !== 'undefined') {
        console.log('Error submitting vote:', error)
      }
    } finally {
      setIsVoting(false)
    }
  }

  // 页面加载时获取对战数据
  useEffect(() => {
    if (status === 'loading') return
    fetchBattleData()
  }, [mode, status])

  // 处理未登录用户的重定向
  useEffect(() => {
    if (status !== 'loading' && !session?.user) {
      router.push('/login')
    }
  }, [session, status, router])

  // 如果用户未登录或正在加载，显示加载状态
  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (!session?.user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="h-full bg-gray-30/50">
      <div className="container mx-auto px-4 h-full flex flex-col justify-center">
        <div className="flex-grow flex flex-col justify-center">
        {/* 头部控制区域 */}
        <div className="py-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <p className="text-gray-600">基于所给提示词，你更喜欢左右哪个结果？</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              {/* 模式切换 */}
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setMode('anonymous')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    mode === 'anonymous'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <EyeSlashIcon className="w-4 h-4 inline mr-2" />
                  匿名对战
                </button>
                <button
                  onClick={() => setMode('public')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    mode === 'public'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <EyeIcon className="w-4 h-4 inline mr-2" />
                  公开对战
                </button>
              </div>

              {/* 刷新按钮 */}
              <button
                onClick={fetchBattleData}
                disabled={isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ArrowPathIcon className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                {isLoading ? '加载中...' : '新对战'}
              </button>
            </div>
          </div>
        </div>

        {/* 对战区域 */}
        {battleData && (
          <div className="flex-grow flex flex-col justify-center">
            {/* Prompt显示 */}
            <div className="bg-gray-50 rounded-lg p-3 flex items-center justify-between gap-4 text-center h-1/12 w-full">
              <p className="text-gray-700 text-sm leading-relaxed flex-1">
                {showEnglishPrompt
                  ? battleData.modelA.prompt
                  : (battleData.modelA.promptZh || battleData.modelA.prompt)
                }
              </p>
              <button
                onClick={() => setShowEnglishPrompt(!showEnglishPrompt)}
                className="flex-shrink-0 p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                title={showEnglishPrompt ? '切换到中文' : '切换到英文'}
              >
                <LanguageIcon className="w-5 h-5" />
              </button>
            </div>

            {/* 图像对比区域 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-grow">
              {/* 模型 A */}
              <div className="relative h-full flex flex-col justify-center">
                {mode === 'public' && showModelNames && (
                  <div className="text-center text-lg font-semibold text-gray-800 mb-2">
                    {battleData.modelA.displayName}
                  </div>
                )}
                <div
                  className="relative w-full group cursor-pointer aspect-w-1 aspect-h-1"
                  onClick={() => handleVote('A')}
                >
                  <Image
                    src={battleData.modelA.image}
                    alt="Model A Image"
                    width={0}
                    height={0}
                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="rounded-lg transition-all duration-200 relative z-10 group-hover:z-20 hover:outline hover:outline-1 hover:outline-offset-2 hover:outline-orange-400"
                  />
                  {mode === 'anonymous' && showModelNames && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white text-xl font-bold rounded-lg z-20">
                      {battleData.modelA.displayName}
                    </div>
                  )}
                </div>
              </div>

              {/* 模型 B */}
              <div className="relative h-full flex flex-col justify-center">
                {mode === 'public' && showModelNames && (
                  <div className="text-center text-lg font-semibold text-gray-800 mb-2">
                    {battleData.modelB.displayName}
                  </div>
                )}
                <div
                  className="relative w-full group cursor-pointer aspect-w-1 aspect-h-1"
                  onClick={() => handleVote('B')}
                >
                  <Image
                    src={battleData.modelB.image}
                    alt="Model B Image"
                    width={0}
                    height={0}
                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="rounded-lg transition-all duration-200 relative z-10 group-hover:z-20 hover:outline hover:outline-1 hover:outline-offset-2 hover:outline-orange-400"
                  />
                  {mode === 'anonymous' && showModelNames && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white text-xl font-bold rounded-lg z-20">
                      {battleData.modelB.displayName}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {mode === 'public' && showResult && voteResult && (
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h2 className="text-2xl font-bold text-center mb-6">投票结果</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold mb-2">{voteResult.modelA.displayName}</h3>
                    <div className="text-sm text-gray-600">
                      评分: {voteResult.modelA.oldRating} → {voteResult.modelA.newRating}
                      <span className={`ml-2 ${
                        voteResult.modelA.newRating > voteResult.modelA.oldRating
                          ? 'text-green-600'
                          : voteResult.modelA.newRating < voteResult.modelA.oldRating
                            ? 'text-red-600'
                            : 'text-gray-600'
                      }`}>
                        ({voteResult.modelA.newRating > voteResult.modelA.oldRating ? '+' : ''}
                        {voteResult.modelA.newRating - voteResult.modelA.oldRating})
                      </span>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="text-lg font-semibold mb-2">{voteResult.modelB.displayName}</h3>
                    <div className="text-sm text-gray-600">
                      评分: {voteResult.modelB.oldRating} → {voteResult.modelB.newRating}
                      <span className={`ml-2 ${
                        voteResult.modelB.newRating > voteResult.modelB.oldRating
                          ? 'text-green-600'
                          : voteResult.modelB.newRating < voteResult.modelB.oldRating
                            ? 'text-red-600'
                            : 'text-gray-600'
                      }`}>
                        ({voteResult.modelB.newRating > voteResult.modelB.oldRating ? '+' : ''}
                        {voteResult.modelB.newRating - voteResult.modelB.oldRating})
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-center mt-8">
                  <button
                    onClick={fetchBattleData}
                    className="px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 transition-colors text-sm"
                  >
                    下一场对战
                  </button>
                </div>
              </div>
            )}

            {/* 投票按钮组 */}
            {!showResult && (
              <div className="flex flex-wrap gap-3 justify-center py-2">
                <button
                  onClick={() => handleVote('A')}
                  disabled={isVoting}
                  className="flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  <ArrowLeftIcon className="w-5 h-5 mr-2" />
                  {isVoting ? '投票中...' : '左边更好'}
                </button>
                <button
                  onClick={() => handleVote('B')}
                  disabled={isVoting}
                  className="flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  <ArrowRightIcon className="w-5 h-5 mr-2" />
                  {isVoting ? '投票中...' : '右边更好'}
                </button>
                <button
                  onClick={() => handleVote('both_good')}
                  disabled={isVoting}
                  className="flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  <ArrowUpIcon className="w-5 h-5 mr-2" />
                  {isVoting ? '投票中...' : '两个都好'}
                </button>
                <button
                  onClick={() => handleVote('both_bad')}
                  disabled={isVoting}
                  className="flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  <ArrowDownIcon className="w-5 h-5 mr-2" />
                  {isVoting ? '投票中...' : '两个都差'}
                </button>
                <button
                  onClick={() => handleVote('skip')}
                  disabled={isVoting}
                  className="flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  <ArrowPathIcon className="w-5 h-5 mr-2" />
                  {isVoting ? '处理中...' : '跳过'}
                </button>
              </div>
            )}
          </div>
        )}
        </div>
        <div className="pt-2 text-center text-gray-500 text-xs">
          <p>内容由人工智能模型生成，可能包含令人不适或不准确的信息。此内容不代表本平台的观点或立场。</p>
        </div>
      </div>
    </div>
  )
}