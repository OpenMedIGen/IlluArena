import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { calculateWinProbability } from '@/lib/elo'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') as 'overall' | 'anonymous' | 'public'

    if (!type || !['overall', 'anonymous', 'public'].includes(type)) {
      return NextResponse.json(
        { error: '无效的排行榜类型' },
        { status: 400 }
      )
    }

    // 根据类型选择对应的ELO字段和投票数字段
    let eloField: string
    let votesField: string

    switch (type) {
      case 'overall':
        eloField = 'eloOverall'
        votesField = 'totalVotes'
        break
      case 'anonymous':
        eloField = 'eloAnonymous'
        votesField = 'anonymousVotes'
        break
      case 'public':
        eloField = 'eloPublic'
        votesField = 'publicVotes'
        break
    }

    // 获取所有模型并按ELO评分排序
    const models = await prisma.model.findMany({
      orderBy: {
        [eloField]: 'desc'
      },
      select: {
        id: true,
        name: true,
        displayName: true,
        eloOverall: true,
        eloAnonymous: true,
        eloPublic: true,
        totalVotes: true,
        anonymousVotes: true,
        publicVotes: true,
        winsOverall: true,
        winsAnonymous: true,
        winsPublic: true
      }
    })

    // 格式化排行榜数据
    const leaderboard = models.map((model, index) => {
      let winsField: string
      switch (type) {
        case 'overall':
          winsField = 'winsOverall'
          break
        case 'anonymous':
          winsField = 'winsAnonymous'
          break
        case 'public':
          winsField = 'winsPublic'
          break
        default:
          winsField = 'winsOverall' // 默认值
      }

      const currentVotes = (model as any)[votesField]
      const currentWins = (model as any)[winsField]

      return {
        id: model.id,
        name: model.name,
        displayName: model.displayName,
        rating: Math.round((model as any)[eloField]), // 四舍五入到整数
        votes: currentVotes,
        rank: index + 1,
        // 计算胜率：获胜次数 / 总投票数
        winRate:
          currentVotes > 0
            ? Math.round((currentWins / currentVotes) * 100)
            : 0, // 百分比，整数
      }
    })

    return NextResponse.json({
      type,
      leaderboard
    })
  } catch (error: any) {
    console.error('获取排行榜错误:', error)
    return NextResponse.json(
      { error: '获取排行榜失败', details: error.message },
      { status: 500 }
    )
  }
}