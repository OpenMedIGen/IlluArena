'use client'

import { useState, useEffect } from 'react'
import { LeaderboardEntry, LeaderboardType } from '@/types'
import { TrophyIcon, EyeIcon, EyeSlashIcon, ChartBarIcon } from '@heroicons/react/24/outline'

export default function LeaderboardPage() {
  const [activeTab, setActiveTab] = useState<LeaderboardType>('overall')
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const tabs = [
    {
      id: 'overall' as LeaderboardType,
      name: '总榜单',
      icon: ChartBarIcon,
      description: ''
    },
    {
      id: 'anonymous' as LeaderboardType,
      name: '匿名榜单',
      icon: EyeSlashIcon,
      description: ''
    },
    {
      id: 'public' as LeaderboardType,
      name: '公开榜单',
      icon: EyeIcon,
      description: ''
    }
  ]

  // 获取排行榜数据
  const fetchLeaderboard = async (type: LeaderboardType) => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/leaderboard?type=${type}`)
      if (response.ok) {
        const data = await response.json()
        setLeaderboardData(data.leaderboard)
      } else {
        console.error('获取排行榜失败')
        setLeaderboardData([])
      }
    } catch (error) {
      console.error('获取排行榜错误:', error)
      setLeaderboardData([])
    } finally {
      setIsLoading(false)
    }
  }

  // 切换标签页
  const handleTabChange = (type: LeaderboardType) => {
    setActiveTab(type)
    fetchLeaderboard(type)
  }

  // 页面加载时获取数据
  useEffect(() => {
    fetchLeaderboard(activeTab)
  }, [])

  // 获取排名颜色
  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'text-yellow-600 bg-yellow-50'
      case 2:
        return 'text-gray-600 bg-gray-50'
      case 3:
        return 'text-orange-600 bg-orange-50'
      default:
        return 'text-gray-500 bg-gray-50'
    }
  }

  // 获取排名图标
  const getRankIcon = (rank: number) => {
    return <span className="font-bold">{rank}</span>
  }

  return (
    <div className="bg-gray-50 flex flex-col h-full">
      <div className="flex-grow overflow-auto px-4 sm:px-6 lg:px-8">
        {/* 头部 */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            模型排行榜
          </h1>
          <p className="text-lg text-gray-600">
            
          </p>
        </div>

        {/* 标签页 */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => {
                const Icon = tab.icon
                return (
                  <button
                    key={tab.id}
                    onClick={() => handleTabChange(tab.id)}
                    className={`group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div>{tab.name}</div>
                      <div className="text-xs text-gray-400">{tab.description}</div>
                    </div>
                  </button>
                )
              })}
            </nav>
          </div>
        </div>

        {/* 排行榜内容 */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
          </div>
        ) : leaderboardData.length > 0 ? (
          <div className="bg-white shadow-sm rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    排名
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    模型名称
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    参与对局数
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Elo得分
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    模型胜率
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {leaderboardData.map((entry) => (
                  <tr key={entry.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${getRankColor(entry.rank)}`}>
                          {getRankIcon(entry.rank)}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {entry.displayName}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {entry.votes}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {entry.rating}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {entry.winRate}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-20">
            <TrophyIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              暂无排行榜数据
            </h3>
            <p className="text-gray-600 mb-4">
              还没有足够的投票数据来生成排行榜
            </p>
            <button
              onClick={() => fetchLeaderboard(activeTab)}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              刷新数据
            </button>
          </div>
        )}

      </div>
    </div>
  )
}