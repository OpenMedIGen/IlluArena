#!/bin/bash

echo "开始清理非必要文件和依赖..."

# 删除 node_modules 目录
if [ -d "node_modules" ]; then
  echo "删除 node_modules 目录..."
  rm -rf node_modules
else
  echo "node_modules 目录不存在，跳过。"
fi

# 删除 .next 目录 (Next.js 构建输出)
if [ -d ".next" ]; then
  echo "删除 .next 目录..."
  rm -rf .next
else
  echo ".next 目录不存在，跳过。"
fi

# 删除 package-lock.json 或 yarn.lock 文件
if [ -f "package-lock.json" ]; then
  echo "删除 package-lock.json 文件..."
  rm package-lock.json
elif [ -f "yarn.lock" ]; then
  echo "删除 yarn.lock 文件..."
  rm yarn.lock
else
  echo "未找到 package-lock.json 或 yarn.lock 文件，跳过。"
fi

# 删除 .env.local 文件 (本地环境变量，通常不应提交到 Git)
if [ -f ".env.local" ]; then
  echo "删除 .env.local 文件..."
  rm .env.local
else
  echo ".env.local 文件不存在，跳过。"
fi

# 删除日志文件
if [ -f "npm-debug.log" ]; then
  echo "删除 npm-debug.log 文件..."
  rm npm-debug.log
fi
if [ -f "yarn-error.log" ]; then
  echo "删除 yarn-error.log 文件..."
  rm yarn-error.log
fi

echo "清理完成。"