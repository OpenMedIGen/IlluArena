import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { calculateELO } from '@/lib/elo'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const mode = searchParams.get('mode') as 'anonymous' | 'public'
    if (!mode || !['anonymous', 'public'].includes(mode)) {
      return NextResponse.json(
        { error: '无效的对战模式' },
        { status: 400 }
      )
    }

    // 获取所有模型
    const models = await prisma.model.findMany()
    if (models.length < 2) {
      return NextResponse.json(
        { error: '模型数量不足，无法进行对战' },
        { status: 400 }
      )
    }

    // 随机选择两个不同的模型
    const shuffled = models.sort(() => 0.5 - Math.random())
    const modelA = shuffled[0]
    const modelB = shuffled[1]

    // 获取这两个模型的图片数据
    type ImageData = Awaited<ReturnType<typeof prisma.imageData.findMany>>[number];
    const imageDataA: ImageData[] = await prisma.imageData.findMany({
      where: { modelId: modelA.id }
    })
    
    const imageDataB: ImageData[] = await prisma.imageData.findMany({
      where: { modelId: modelB.id }
    })

    // 找到相同promptId的图片
    const commonPrompts = imageDataA
      .filter(a => imageDataB.some(b => b.promptId === a.promptId))
      .map(a => a.promptId)
    if (commonPrompts.length === 0) {
      return NextResponse.json(
        { error: '没有找到相同prompt的图片数据' },
        { status: 400 }
      )
    }

    // 随机选择一个prompt
    const selectedPromptId = commonPrompts[Math.floor(Math.random() * commonPrompts.length)]
    
    const imageA = imageDataA.find(img => img.promptId === selectedPromptId)!
    const imageB = imageDataB.find(img => img.promptId === selectedPromptId)!

    const battleData = {
      id: `battle_${Date.now()}`,
      modelA: {
        id: modelA.id,
        name: modelA.name,
        displayName: modelA.displayName,
        image: imageA.imagePath,
        prompt: imageA.prompt,
        promptZh: imageA.promptZh
      },
      modelB: {
        id: modelB.id,
        name: modelB.name,
        displayName: modelB.displayName,
        image: imageB.imagePath,
        prompt: imageB.prompt,
        promptZh: imageB.promptZh
      },
      mode,
      promptId: selectedPromptId
    }

    return NextResponse.json(battleData)
  } catch (error) {
    console.error('获取对战数据错误:', error)
    return NextResponse.json(
      { error: '获取对战数据失败' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  console.log('Received POST request to /api/battle');
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      console.log('Session user not found, returning 401');
      return NextResponse.json(
        { error: '请先登录' },
        { status: 401 }
      )
    }
    console.log('Session user ID:', session.user.id);

    const { modelAId, modelBId, result, mode, promptId } = await request.json()
    console.log('Request body:', { modelAId, modelBId, result, mode, promptId });

    if (!modelAId || !modelBId || !result || !mode || !promptId) {
      console.log('Missing required parameters, returning 400');
      return NextResponse.json(
        { error: '缺少必要参数' },
        { status: 400 }
      )
    }

    if (!['A', 'B', 'both_good', 'both_bad', 'skip'].includes(result)) {
      console.log('Invalid vote result, returning 400');
      return NextResponse.json(
        { error: '无效的投票结果' },
        { status: 400 }
      )
    }
    
    // 如果是跳过，不记录投票
    if (result === 'skip') {
      console.log('Skipping vote, returning success');
      return NextResponse.json({ success: true, skipped: true })
    }

    console.log('session.user.id:', session.user.id);
    // 检查用户是否存在
    const userExists = await prisma.user.findUnique({
      where: { id: session.user.id },
    });

    if (!userExists) {
      console.log('User not found, returning 404');
      return NextResponse.json({ error: '用户未找到' }, { status: 404 });
    }
    console.log('User exists:', userExists.id);

    // 记录对战结果
    const battle = await prisma.battle.create({
      data: {
        userId: session.user.id, // 直接使用 userId
        modelAId,
        modelBId,
        promptId,
        mode,
        result
      }
    })

    // 获取模型当前评分
    const [modelA, modelB] = await prisma.model.findMany({
      where: {
        id: {
          in: [modelAId, modelBId]
        }
      },
      select: {
        id: true,
        eloOverall: true,
        eloAnonymous: true,
        eloPublic: true,
        totalVotes: true,
        anonymousVotes: true,
        publicVotes: true,
        winsOverall: true,
        winsAnonymous: true,
        winsPublic: true
      }
    })

    if (!modelA || !modelB) {
      return NextResponse.json({ error: '模型未找到' }, { status: 404 })
    }

    let ratingA: number, ratingB: number
    let newEloOverallA: number, newEloOverallB: number
    let newEloAnonymousA: number, newEloAnonymousB: number
    let newEloPublicA: number, newEloPublicB: number

    // 根据模式选择对应的ELO评分
    if (mode === 'anonymous') {
      ratingA = modelA.eloAnonymous
      ratingB = modelB.eloAnonymous
    } else {
      ratingA = modelA.eloPublic
      ratingB = modelB.eloPublic
    }

    // 计算新的ELO评分
    const { newRatingA, newRatingB } = calculateELO(ratingA, ratingB, result)

    // 更新对应模式的ELO评分
    if (mode === 'anonymous') {
      newEloAnonymousA = newRatingA
      newEloAnonymousB = newRatingB
      newEloPublicA = modelA.eloPublic
      newEloPublicB = modelB.eloPublic
    } else {
      newEloPublicA = newRatingA
      newEloPublicB = newRatingB
      newEloAnonymousA = modelA.eloAnonymous
      newEloAnonymousB = modelB.eloAnonymous
    }

    // 更新总ELO评分 (这里可以根据需要调整，例如加权平均或只更新特定模式)
    // 简单处理：如果只有一种模式，则总分等于该模式分数；如果有两种模式，则取平均值
    newEloOverallA = (newEloAnonymousA + newEloPublicA) / 2
    newEloOverallB = (newEloAnonymousB + newEloPublicB) / 2

    // 更新投票计数
    const updateDataA: any = {
      totalVotes: { increment: 1 }
    }
    const updateDataB: any = {
      totalVotes: { increment: 1 }
    }

    if (mode === 'anonymous') {
      updateDataA.anonymousVotes = { increment: 1 }
      updateDataB.anonymousVotes = { increment: 1 }
    } else {
      updateDataA.publicVotes = { increment: 1 }
      updateDataB.publicVotes = { increment: 1 }
    }

    // 更新模型评分和投票计数
    await prisma.$transaction([
      prisma.model.update({
        where: { id: modelAId },
        data: {
          eloOverall: newEloOverallA,
          eloAnonymous: newEloAnonymousA,
          eloPublic: newEloPublicA,
          ...updateDataA,
          winsOverall:
            result === 'A' || result === 'both_good'
              ? { increment: 1 }
              : undefined,
          winsAnonymous:
            mode === 'anonymous' && (result === 'A' || result === 'both_good')
              ? { increment: 1 }
              : undefined,
          winsPublic:
            mode === 'public' && (result === 'A' || result === 'both_good')
              ? { increment: 1 }
              : undefined,
        },
      }),
      prisma.model.update({
        where: { id: modelBId },
        data: {
          eloOverall: newEloOverallB,
          eloAnonymous: newEloAnonymousB,
          eloPublic: newEloPublicB,
          ...updateDataB,
          winsOverall:
            result === 'B' || result === 'both_good'
              ? { increment: 1 }
              : undefined,
          winsAnonymous:
            mode === 'anonymous' && (result === 'B' || result === 'both_good')
              ? { increment: 1 }
              : undefined,
          winsPublic:
            mode === 'public' && (result === 'B' || result === 'both_good')
              ? { increment: 1 }
              : undefined,
        },
      }),
    ]);

    return NextResponse.json({ success: true, battleId: battle.id })
  } catch (error) {
    console.error('提交投票错误:', error)
    return NextResponse.json(
      { error: '提交投票失败' },
      { status: 500 }
    )
  }
}