'use client'

import React, { useState, useEffect, useCallback } from 'react';

interface FireworksProps {
  onExplode: boolean;
  onComplete: () => void;
}

const Fireworks: React.FC<FireworksProps> = ({ onExplode, onComplete }) => {
  const [fireworks, setFireworks] = useState<{ id: number; x: number; y: number }[]>([]);
  const [explosionCount, setExplosionCount] = useState(0);

  const createFirework = useCallback((x: number, y: number) => {
    const id = Date.now() + Math.random();
    setFireworks((prev) => [...prev, { id, x, y }]);
    setExplosionCount((prev) => prev + 1);
  }, []);

  useEffect(() => {
    if (onExplode) {
      // Trigger multiple fireworks at random positions
      for (let i = 0; i < 5; i++) {
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        createFirework(x, y);
      }
    }
  }, [onExplode, createFirework]);

  useEffect(() => {
    if (explosionCount > 0 && fireworks.length === 0) {
      onComplete();
      setExplosionCount(0); // Reset count after completion
    }
  }, [fireworks.length, explosionCount, onComplete]);

  const handleAnimationEnd = useCallback((id: number) => {
    setFireworks((prev) => prev.filter((f) => f.id !== id));
  }, []);

  return (
    <>
      {fireworks.map((f) => (
        <div
          key={f.id}
          className="firework"
          style={{ left: f.x, top: f.y }}
          onAnimationEnd={() => handleAnimationEnd(f.id)}
        >
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
          <div className="explosion"></div>
        </div>
      ))}
      <style jsx global>{`
        .firework {
          position: fixed;
          transform: translate(-50%, -50%);
          width: 10px;
          height: 10px;
          opacity: 0;
          animation: fadeOut 1s forwards;
          z-index: 9999;
        }

        .explosion {
          position: absolute;
          width: 4px;
          height: 4px;
          background-color: #ffeb3b; /* Yellow */
          border-radius: 50%;
          animation: explode 0.8s ease-out forwards;
        }

        .explosion:nth-child(1) { transform: rotate(0deg) translate(10px) scale(0); animation-delay: 0s; }
        .explosion:nth-child(2) { transform: rotate(45deg) translate(10px) scale(0); animation-delay: 0.1s; }
        .explosion:nth-child(3) { transform: rotate(90deg) translate(10px) scale(0); animation-delay: 0.2s; }
        .explosion:nth-child(4) { transform: rotate(135deg) translate(10px) scale(0); animation-delay: 0.3s; }
        .explosion:nth-child(5) { transform: rotate(180deg) translate(10px) scale(0); animation-delay: 0.4s; }
        .explosion:nth-child(6) { transform: rotate(225deg) translate(10px) scale(0); animation-delay: 0.5s; }
        .explosion:nth-child(7) { transform: rotate(270deg) translate(10px) scale(0); animation-delay: 0.6s; }
        .explosion:nth-child(8) { transform: rotate(315deg) translate(10px) scale(0); animation-delay: 0.7s; }

        @keyframes explode {
          0% {
            transform: scale(0);
            opacity: 1;
          }
          50% {
            transform: scale(1.5);
            opacity: 1;
          }
          100% {
            transform: scale(0);
            opacity: 0;
          }
        }

        @keyframes fadeOut {
          0% { opacity: 1; }
          100% { opacity: 0; }
        }
      `}</style>
    </>
  );
};

export default Fireworks;