'use client'

import Image from 'next/image'

import { useState } from 'react'
import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  HomeIcon,
  TrophyIcon,
  UserIcon,
  ArrowRightOnRectangleIcon,
  ArrowLeftOnRectangleIcon,
  ChevronLeftIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline'

export function Sidebar({ isCollapsed, setIsCollapsed }: { isCollapsed: boolean; setIsCollapsed: (collapsed: boolean) => void }) {
  const { data: session, status } = useSession()
  const pathname = usePathname()

  const navigation = [
    {
      name: '文生图评估',
      href: '/battle',
      icon: HomeIcon,
      description: '模型对战'
    },
    {
      name: '排行榜',
      href: '/leaderboard',
      icon: TrophyIcon,
      description: 'ELO排名'
    }
  ]

  const isActive = (href: string) => {
    if (href === '/battle') {
      return pathname === '/' || pathname === '/battle'
    }
    return pathname === href
  }

  return (
    <div className={`fixed inset-y-0 left-0 z-50 bg-white shadow-lg transition-all duration-300 ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div className="flex flex-col h-full">
        {/* Logo and Collapse Button */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
          {!isCollapsed && (
            <Image src="/logo.png" alt="Logo" width={170} height={64} />
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
          >
            {isCollapsed ? (
              <ChevronRightIcon className="w-6 h-6 text-gray-500" />
            ) : (
              <ChevronLeftIcon className="w-6 h-6 text-gray-500" />
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`
                  flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors
                  ${isActive(item.href)
                    ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                    : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                  }
                  ${isCollapsed ? 'justify-center' : ''}
                `}
              >
                <Icon className={`w-5 h-5 ${!isCollapsed ? 'mr-3' : ''}`} />
                {!isCollapsed && (
                  <div>
                    <div>{item.name}</div>
                    <div className="text-xs text-gray-500">{item.description}</div>
                  </div>
                )}
              </Link>
            )
          })}
        </nav>

        {/* User Section */}
        <div className="border-t border-gray-200 p-4">
          {status === 'loading' ? (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
              {!isCollapsed && (
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                </div>
              )}
            </div>
          ) : session?.user ? (
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-blue-600" />
                </div>
                {!isCollapsed && (
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {session.user.username}
                    </p>
                    <p className="text-xs text-gray-500 truncate">
                      {session.user.email}
                    </p>
                  </div>
                )}
              </div>
              {!isCollapsed && (
                <button
                  onClick={() => signOut()}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <ArrowRightOnRectangleIcon className="w-4 h-4 mr-2" />
                  退出登录
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <Link
                href="/login"
                className={`flex items-center w-full px-3 py-2 text-sm text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors ${isCollapsed ? 'justify-center' : ''}`}
              >
                <ArrowLeftOnRectangleIcon className={`w-4 h-4 ${!isCollapsed ? 'mr-2' : ''}`} />
                {!isCollapsed && '登录'}
              </Link>
              <Link
                href="/register"
                className={`flex items-center w-full px-3 py-2 text-sm text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors ${isCollapsed ? 'justify-center' : ''}`}
              >
                <UserIcon className={`w-4 h-4 ${!isCollapsed ? 'mr-2' : ''}`} />
                {!isCollapsed && '注册'}
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}