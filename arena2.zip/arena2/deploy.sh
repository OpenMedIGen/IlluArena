#!/bin/bash

echo "开始部署项目..."

# 检查并安装依赖
echo "换源"
# 统一给 npm 也换源（防止脚本走 npm 分支时还是原源）
if command -v npm &>/dev/null; then
  npm config set registry https://registry.npmmirror.com
fi

if command -v yarn &>/dev/null; then
  YV=$(yarn -v | cut -d. -f1)
  if [ "$YV" = "1" ]; then
    # Yarn v1：用 registry 键
    yarn config set registry https://registry.npmmirror.com
    # 常见二进制依赖镜像（按需）
    yarn config set disturl https://npmmirror.com/mirrors/node
    yarn config set sass_binary_site https://npmmirror.com/mirrors/node-sass
    yarn config set electron_mirror https://npmmirror.com/mirrors/electron/
    yarn config set puppeteer_download_host https://npmmirror.com/mirrors
  else
    # Yarn v2+/Berry：用 npmRegistryServer 键（项目级）
    yarn config set npmRegistryServer https://registry.npmmirror.com
    # 若不想用 PnP，可启用 node_modules（可选）
    yarn config set nodeLinker node-modules
  fi
  # 清理缓存避免走旧源
  yarn cache clean
fi


echo "安装项目依赖..."
if command -v npm &> /dev/null; then
  npm install
elif command -v yarn &> /dev/null; then
  yarn install
else
  echo "错误: 未找到 npm 或 yarn。请确保已安装 Node.js 和包管理器。"
  exit 1
fi

# 检查 .env 文件是否存在
if [ ! -f ".env" ]; then
  echo "警告: .env 文件不存在。请根据 .env.example 创建并配置您的环境变量。"
  echo "部署可能无法正常进行，请手动配置 .env 文件后重试。"
  # 可以在这里添加一个暂停或退出，取决于是否强制要求 .env 文件
fi

# 运行 Prisma 迁移和生成客户端
echo "运行 Prisma 迁移并生成客户端..."
npx prisma migrate dev --name init # 使用 dev 模式，如果需要生产环境部署，请考虑使用 deploy
npx prisma generate

# 填充初始数据 (可选)
echo "填充初始数据 (可选)..."
npm run seed

echo "项目部署完成。您现在可以使用 'npm run dev' 启动开发服务器。"